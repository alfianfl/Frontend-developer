import React, { Component } from 'react';


class Checkout extends Component {
  render() {
    return (
      <>
      </>
    );
  }
}

export default Checkout;
