import React, { Component } from 'react';


class Teaching extends Component {
  render() {
    return (
      <>
        <p>Teaching</p>
      </>
    );
  }
}

export default Teaching;
