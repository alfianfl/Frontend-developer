@extends('layout.base_layout_admin')

{{-- title --}}
@section('title')
Download
@endsection


@section('link_css')
<link href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css" rel="stylesheet"
    crossorigin="anonymous" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="{{ url('./assets/css/downloadAdmin.css') }}" crossorigin="anonymous">
@endsection

@section('content')
<div id="layoutSidenav">
    @include('admin.sideNav.sideNav')
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="thumb-certificate py-2 px-2">
                            <div>
                                <strong>Certificate Status</strong>
                            </div>
                            <div class="onoffswitch">
                                <form method="GET" action="" id="onoffswitch">
                                    <input type="checkbox" name="onoffswitch" class="onoffswitch-checkbox"
                                        id="myonoffswitch" tabindex="0" value="1" checked>
                                    <label class="onoffswitch-label" for="myonoffswitch">
                                        <span class="onoffswitch-inner"></span>
                                        <span class="onoffswitch-switch"></span>
                                    </label>
                                    <div class="button-submit">
                                        <button class="btn btn-success">Edit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <h1 class="mt-4">Tables Download</h1>
                <div class="card mb-4">
                    <div class="card-header">
                        <a href="{{url('/admin/download/inputDownload')}}"> <button class="btn btn-primary">Input new
                                Template</button></a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>File Upload</th>
                                        <th>Conference</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Shad Decker</td>
                                        <td>test......</td>
                                        <td>test.....</td>
                                        <td class="text-center">
                                            <a href="{{url('/admin/download/editDownload')}}"><i style="color:#35C668"
                                                    class="fas fa-edit"></i> </a>
                                            <i data-toggle="modal" data-target=".bd-delete-modal-admin2"
                                                style="color:#C43030" class="fas fa-trash color-danger"></i>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
{{-- POP UP DELETE --}}
<div class="modal fade bd-delete-modal-admin2" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel"
    id="modal-delete" aria-hidden="true">
    <div class="modal-dialog modal-md">
        <div class="modal-content px-3 pt-2 pb-4 ">
            <div class="modal-title">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <h1 class="text-center text-delete" style="font-size:20px">
                Delete
            </h1>
            <h1 class="text-center mt-3 font-weight-normal" style="font-size:15px">
                Are you sure you want to delete?
            </h1>
            <div class="mt-3">
                <div class="d-flex justify-content-around">
                    <div class="button w-50 mx-3">
                        <button data-dismiss="modal" type="button"
                            class="btn btn-delete btn-secondary w-100">Keep</button>
                    </div>
                    <div class="button w-50 mx-3">
                        <a href="" id="deletePayments">
                            <button class="btn btn-delete btn-danger w-100">Delete</button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('link_js')
<script>
    $( document ).ready(function() {
        var switchStatus = 0;
     
$("#myonoffswitch").on('change', function() {
    if ($(this).is(':checked')) {
        switchStatus = 1;
        $('.onoffswitch').find('#onoffswitch').attr('action',`/unpad-icocome2021/switch/on`)
        alert(switchStatus);// To verify
    }
    else {
       switchStatus = 0;
        $('.onoffswitch').find('#onoffswitch').attr('action',`/unpad-icocome2021/switch/off`)
       alert(switchStatus);// To verify
    }
});
//         $('input[type="checkbox"]').on('change', function(e){
//         if($(this).prop('checked'))
//         {
//             $(this).next().val(1);
//             console.log($(this).next())
//         } else {
//             $(this).next().val(0);
//             console.log($(this).next())
//         }
// }); 
    });
</script>
@endsection