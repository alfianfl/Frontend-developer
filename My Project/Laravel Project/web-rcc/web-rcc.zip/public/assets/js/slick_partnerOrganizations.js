$('.section-partner-mobile').slick({
    slidesToShow: 2,
    slidesToScroll: 1,
    dots: true,
    arrows: true,
    autoplayspeed: 2000,
    infiniite: true
});